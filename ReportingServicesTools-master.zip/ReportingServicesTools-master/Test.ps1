Invoke-Pester -Path .\Tests\CatalogItems
Invoke-Pester -Path .\Tests\Utilities
